


public class main {

 public static void main(String[] args) {
     SearchingTechniques S = new SearchingTechniques();
     table goal_table=new table('w','w','w','w', ' ');
     table initial_table=new table('e','e','e','e', ' ');
     multitree tree=new multitree(initial_table);
        long t1=System.nanoTime();
        S.Depth(tree,goal_table);
        long t2=System.nanoTime();
  
        System.out.println("Depth: "+(t2-t1));
  
 }
}
