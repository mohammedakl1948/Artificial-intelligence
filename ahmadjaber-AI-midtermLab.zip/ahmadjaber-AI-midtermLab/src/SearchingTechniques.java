public class SearchingTechniques {

    protected int jDepth = 8;
    protected boolean found = false;
    protected multitree<table> tree;

    
    
    public void Depth(multitree tree1,table goal)
    {
        this.tree=tree1;
        Depth(tree.root,goal,0);
    }

    public void Depth(multinode node,table goal, int c) {
        
        c++;
        if (c > jDepth || found) {
            return;
        }
        
        table table_node = (table) node.data;

        if (table_node.isEqual(goal))
        {
            tree.display_solution(node);
            found = true;
        } 
        else
        {
            table new_table1 = new table();
            new_table1=apply(1, table_node);
            table new_table2 = new table();
            new_table2=apply(2, table_node);
            table new_table3 = new table();
            new_table3=apply(3, table_node);
            table new_table4 = new table();
            new_table4=apply(4, table_node);
            table new_table5 = new table();
            new_table4=apply(5, table_node);
            table new_table6 = new table();
            new_table4=apply(6, table_node);
            table new_table7 = new table();
            new_table4=apply(7, table_node);
            table new_table8 = new table();
            new_table4=apply(8, table_node);
            table new_table9 = new table();
            new_table4=apply(9, table_node);
            table new_table10 = new table();
            new_table4=apply(10, table_node);
            
            
            
            
            
            
            
            if (new_table1 != null) {
                tree.insertnode(new_table1,node.id);
                Depth(tree.search_data(new_table1), goal,c);
            }
            if (new_table2 != null) {
                tree.insertnode(new_table2,node.id);
                Depth(tree.search_data(new_table2), goal,c);
            }
            if (new_table3 != null) {
                tree.insertnode(new_table3,node.id);
                Depth(tree.search_data(new_table3), goal,c);
            }
            if (new_table4 != null) {
                tree.insertnode(new_table4,node.id);
                Depth(tree.search_data(new_table4), goal,c);
            } 
            if (new_table5 != null) {
                tree.insertnode(new_table5,node.id);
                Depth(tree.search_data(new_table5), goal,c);
            }
            if (new_table6 != null) {
                tree.insertnode(new_table6,node.id);
                Depth(tree.search_data(new_table6), goal,c);
            }
            if (new_table7 != null) {
                tree.insertnode(new_table7,node.id);
                Depth(tree.search_data(new_table7), goal,c);
            }
            if (new_table8 != null) {
                tree.insertnode(new_table8,node.id);
                Depth(tree.search_data(new_table8), goal,c);
            }
            if (new_table9 != null) {
                tree.insertnode(new_table9,node.id);
                Depth(tree.search_data(new_table9), goal,c);
            }
            if (new_table10 != null) {
                tree.insertnode(new_table10,node.id);
                Depth(tree.search_data(new_table10), goal,c);
            }
            
        }
    }
    
  
    public static table apply(int op, table before) {
        table after = new table(before);
        char A = before.getA();
        char B = before.getB();
        char C = before.getC();
        char D = before.getD();
        char T = before.getTorch();
        switch (op) {
            case 1:
            	if(A==A&&A==T) {
            		after.torch=after.a= A =='e'?'w':'e';
            		after.action="A goes with T";
            	}else return null;
                break;

            case 2:
                if (B==B && B==T) {
                     after.torch=after.b=B=='e'?'w':'e';
                    after.action="B goes with T";
                } else {
                    return null;
                }
                break;
            case 3:
                if (C==C && C==T) {
                    after.torch=after.c=C=='e'?'w':'e';
                    after.action="C goes with T";
                } else {
                    return null;
                }
                break;
            case 4: 
            	if(D==D && D==T) {
            		after.torch=after.d=D=='e'?'w':'e';
            		after.action="D goes with T";
            	}else return null;
            	break;
            	
            case 5:
                if(A==B && A==T) {
                after.torch=after.b=after.a= A =='e'?'w':'e';
                after.action = "A goes with B and T ";
                }else return null;
                break;
                
            case 6:
            	if(A==C && A==T) {
            		after.torch=after.c=after.a= A =='e'?'w':'e';
                    after.action = "A goes with C and T ";
            	}else return null;
                break;
            case 7:
            	if(A==D && A==T) {
            		after.torch=after.d=after.a= A =='e'?'w':'e';
                    after.action = "A goes with D and T ";
            	}else return null;
            	break;
            case 8:
            	if(B==C && B==T) {
            		after.torch=after.c=after.b= B =='e'?'w':'e';
                    after.action = "B goes with C and T ";
            	}else return null;
            	break;
            case 9:
            	if(B==D && B==T) {
            		after.torch=after.d=after.b= B =='e'?'w':'e';
                    after.action = "B goes with D and T ";
            	}else return null;
            	break;
            case 10:
            	if(C==D && C==T) {
            		after.torch=after.d=after.c= C =='e'?'w':'e';
                    after.action = "C goes with D and T ";
            	}else return null;
            	break;
                
            default:
                return null;
        }
        if((after.b==after.c&&after.a!=after.c)||(after.c==after.d&&after.a!=after.c))
            return null;
        return after;
    }
}