public class table {
	char a, b, c, d, torch;
	String action = "Initial State";
	public char getA() {
		return a;
	}

	public void setA(char a) {
		this.a = a;
	}

	public char getB() {
		return b;
	}

	public void setB(char b) {
		this.b = b;
	}

	public char getC() {
		return c;
	}

	public void setC(char c) {
		this.c = c;
	}

	public char getD() {
		return d;
	}

	public void setD(char d) {
		this.d = d;
	}

	public char getTorch() {
		return torch;
	}

	public void setTorch(char torch) {
		this.torch = torch;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public int getMinutes() {
		return minutes;
	}

	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}

	int minutes = 0;

	public table() {

	}

	public table(char a, char b, char c, char d, char torch) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.torch = torch;
	}

	public table(table t) {
		a = t.a;
		b = t.b;
		c = t.c;
		d = t.d;
		torch = t.torch;
	}

	public String eORw(char direction) {
		if (direction == 'e') {
			return "East";
		}
		if (direction == 'w') {
			return "West";
		}
		return "Error";
	}

	public boolean isEqual(table t) {
		if (t == null)
			return false;

		if (a == t.a && b == t.b && d == t.d && c == t.c && torch == t.torch)
			return true;
		return false;
	}

	@Override
	public String toString() {
		String str = action + ": Person A is on=  " + eORw(a) + ", Person B is on " + eORw(b) + ", Person C is on "
				+ eORw(c) + ", Person D is on " + eORw(d) + ", The torch is on " + eORw(torch);
		return str;
	}
}